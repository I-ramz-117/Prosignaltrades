import os

# Obtener el TOKEN del bot desde las variables de entorno en Replit
BOT_TOKEN = os.getenv("BOT_TOKEN")

if not BOT_TOKEN:
    raise ValueError("❌ ERROR: No se encontró el BOT_TOKEN en las variables de entorno.")