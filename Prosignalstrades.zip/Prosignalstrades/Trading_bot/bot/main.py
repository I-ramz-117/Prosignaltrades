import logging
from telegram.ext import Application, CommandHandler
from keep_alive import keep_alive  # Importar el servidor Flask desde la raíz
from Trading_bot.bot.config import BOT_TOKEN  # Importar el token desde config.py
from Trading_bot.strategies.technical_analysis import technical_analysis  # Importar el análisis técnico

# Iniciar el servidor Flask para mantener el bot activo en Replit
keep_alive()

# ✅ Configurar logs para depuración
logging.basicConfig(level=logging.INFO)

# ✅ Inicializar el bot con Application
app = Application.builder().token(BOT_TOKEN).build()


# ✅ Función para manejar el comando /start
async def start(update, context):
    await update.message.reply_text(
        "✅ ¡Bot de Trading activo! Usa /analizar <símbolo> para obtener análisis técnico."
    )


# ✅ Función para manejar el comando /analizar
async def analizar(update, context):
    if not context.args:
        await update.message.reply_text("⚠️ Uso: /analizar <símbolo>")
        return

    symbol = context.args[0].upper()
    await update.message.reply_text(
        f"📊 Análisis Técnico de {symbol}\n🔍 Procesando...")

    # 📌 Llamar a la función de análisis técnico
    analysis = technical_analysis(symbol)

    # 📌 Verificar si `technical_analysis` retorna un diccionario con 'text'
    if isinstance(analysis, dict) and "text" in analysis:
        await update.message.reply_text(analysis["text"],
                                        parse_mode="Markdown")
    else:
        await update.message.reply_text("❌ No se pudo obtener datos.")


# ✅ Agregar los comandos al bot
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("analizar", analizar))


# ✅ Iniciar el bot en modo polling
print("🚀 Bot de Trading en ejecución...")
app.run_polling()
