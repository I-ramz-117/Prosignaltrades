import yfinance as yf
from datetime import datetime
import numpy as np

def get_current_price(symbol):
    """
    Obtiene el precio actual de la acción desde Yahoo Finance junto con la hora exacta de consulta.
    """
    try:
        stock = yf.Ticker(symbol)
        current_data = stock.history(period="1d")

        # 📌 Validar que los datos no estén vacíos
        if current_data.empty or "Close" not in current_data.columns:
            print(f"❌ No se encontraron datos recientes para {symbol}.")
            return np.nan, "N/A"

        # 📌 Obtener el último precio de cierre sin errores
        current_price = current_data["Close"].dropna()
        if current_price.empty:
            print(f"❌ El precio de cierre para {symbol} no está disponible.")
            return np.nan, "N/A"

        current_price = round(current_price.iloc[-1], 2)  # Último precio válido
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Hora exacta de consulta

        return current_price, timestamp

    except Exception as e:
        print(f"❌ Error al obtener el precio de {symbol}: {e}")
        return np.nan, "N/A"