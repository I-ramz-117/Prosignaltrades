import numpy as np
import pandas as pd
import yfinance as yf
from ta.trend import EMAIndicator, MACD, ADXIndicator
from ta.momentum import RSIIndicator
from ta.volatility import BollingerBands

def calculate_technical_indicators(df):
    """Calcula indicadores técnicos y devuelve un DataFrame actualizado."""

    # 📌 Evitar modificar el DataFrame original
    df = df.copy()

    # 📌 Asegurar que todas las columnas numéricas sean de tipo float
    numeric_cols = ["close", "open", "high", "low", "volume"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # 📌 Manejo de valores NaN (rellenar con valores previos)
    df.ffill(inplace=True)  # Usa forward fill sin warning

    # 📌 Verificar si hay suficientes datos antes de eliminar NaN
    min_data_points = 50  # Un mínimo recomendado para evitar pérdida de datos
    if len(df) > min_data_points:
        df.dropna(inplace=True)

    # 📌 Cálculo de indicadores técnicos
    df["RSI"] = RSIIndicator(df["close"]).rsi()
    df["EMA_20"] = EMAIndicator(df["close"], window=20).ema_indicator()
    df["EMA_50"] = EMAIndicator(df["close"], window=50).ema_indicator()

    macd = MACD(df["close"])
    df["MACD"] = macd.macd()
    df["MACD_Signal"] = macd.macd_signal()

    df["ATR"] = df["high"].rolling(window=14).max() - df["low"].rolling(window=14).min()

    # 📌 Bandas de Bollinger
    bb = BollingerBands(df["close"], window=20, window_dev=2)
    df["BB_High"] = bb.bollinger_hband()
    df["BB_Low"] = bb.bollinger_lband()
    df["BB_Mid"] = bb.bollinger_mavg()

    # 📌 Índice de Dirección Promedio (ADX)
    adx = ADXIndicator(df["high"], df["low"], df["close"], window=14)
    df["ADX"] = adx.adx()

    # 📌 Volumen Promedio (SMA_14) solo si existe la columna "volume"
    if "volume" in df.columns:
        df["SMA_14"] = df["volume"].rolling(window=14).mean()
    else:
        df["SMA_14"] = np.nan  # Si no hay volumen, asigna NaN para evitar errores

    return df

def get_stock_data(symbol):
    """Descarga los datos de una acción específica en Yahoo Finance"""
    try:
        df = yf.download(symbol, period="2y", interval="1d")

        # 📌 Si el DataFrame tiene un MultiIndex en las columnas, lo corregimos
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.droplevel(1)  # Elimina el segundo nivel de las columnas

        # 📌 Renombrar columnas al formato esperado
        df = df.rename(columns={"Open": "open", "High": "high", "Low": "low", "Close": "close", "Volume": "volume"})

        # 📌 Convertir columnas a float para evitar errores en cálculos
        numeric_cols = ["close", "open", "high", "low", "volume"]
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        return df

    except Exception as e:
        print(f"❌ Error al descargar datos de {symbol}: {e}")
        return None