import pandas as pd

def detect_candlestick_patterns(df):
    """Detecta patrones de velas japonesas importantes."""
    patterns = []

    last_candle = df.iloc[-1]
    prev_candle = df.iloc[-2]

    open_price, high_price, low_price, close_price = last_candle["open"], last_candle["high"], last_candle["low"], last_candle["close"]
    prev_open, prev_close = prev_candle["open"], prev_candle["close"]

    # 📌 Martillo (Hammer) - Posible reversión alcista en soporte
    if (close_price > open_price) and ((high_price - close_price) < (open_price - low_price) * 0.5):
        patterns.append("🟢 Martillo - Posible rebote alcista en soporte.")

    # 📌 Hombre Colgado (Hanging Man) - Posible reversión bajista en resistencia
    if (open_price > close_price) and ((high_price - open_price) < (close_price - low_price) * 0.5):
        patterns.append("🔴 Hombre Colgado - Posible reversión bajista en resistencia.")

    # 📌 Engulfing Alcista - Señal de reversión alcista
    if prev_close < prev_open and close_price > open_price and close_price > prev_open and open_price < prev_close:
        patterns.append("🟢 Engulfing Alcista - Señal de posible cambio de tendencia al alza.")

    # 📌 Engulfing Bajista - Señal de reversión bajista
    if prev_close > prev_open and close_price < open_price and close_price < prev_open and open_price > prev_close:
        patterns.append("🔴 Engulfing Bajista - Señal de posible caída del precio.")

    # 📌 Doji - Indecisión en el mercado
    if abs(close_price - open_price) < (high_price - low_price) * 0.1:
        patterns.append("⚪ Doji - Indecisión en el mercado, posible cambio de tendencia.")

    # 📌 Three White Soldiers - Señal alcista fuerte
    if (df["close"].iloc[-3] < df["open"].iloc[-3]) and (df["close"].iloc[-2] > df["open"].iloc[-2]) and \
       (df["close"].iloc[-1] > df["open"].iloc[-1]) and (df["close"].iloc[-1] > df["close"].iloc[-2] > df["close"].iloc[-3]):
        patterns.append("🟢 Three White Soldiers - Patrón alcista fuerte, posible inicio de tendencia.")

    # 📌 Three Black Crows - Señal bajista fuerte
    if (df["close"].iloc[-3] > df["open"].iloc[-3]) and (df["close"].iloc[-2] < df["open"].iloc[-2]) and \
       (df["close"].iloc[-1] < df["open"].iloc[-1]) and (df["close"].iloc[-1] < df["close"].iloc[-2] < df["close"].iloc[-3]):
        patterns.append("🔴 Three Black Crows - Patrón bajista fuerte, posible caída en el precio.")

    return patterns if patterns else ["⚪ Sin patrones detectados."]