import numpy as np

def calculate_support_resistance(df, pivot_window=5, min_touch=2, sensitivity=0.03):
    """
    Calcula soportes y resistencias combinando:
    - Máximos y mínimos recientes (ventana móvil)
    - Puntos Pivotantes (Máximos y Mínimos Locales)
    - Filtrado de niveles tocados varias veces
    - Sensibilidad ajustable para detectar rangos de soporte/resistencia

    Args:
        df (DataFrame): DataFrame con precios históricos.
        pivot_window (int): Número de velas para determinar un máximo/mínimo local.
        min_touch (int): Mínimo de veces que un nivel debe ser tocado para ser válido.
        sensitivity (float): Tolerancia en porcentaje para definir rangos de soporte/resistencia.

    Returns:
        (float, float): Niveles de soporte y resistencia más relevantes.
    """

    highs = df["high"].values
    lows = df["low"].values

    resistance_levels = []
    support_levels = []

    # 🔹 DETECCIÓN DE SOPORTES Y RESISTENCIAS POR PUNTOS PIVOTANTES
    for i in range(pivot_window, len(df) - pivot_window):
        local_max = max(highs[i - pivot_window : i + pivot_window + 1])
        local_min = min(lows[i - pivot_window : i + pivot_window + 1])

        if highs[i] == local_max:
            resistance_levels.append(highs[i])
        if lows[i] == local_min:
            support_levels.append(lows[i])

    # 🔹 FILTRADO DE SOPORTES Y RESISTENCIAS MÁS IMPORTANTES
    resistance_counts = {level: sum(1 for x in highs if abs(x - level) <= sensitivity * level) for level in resistance_levels}
    support_counts = {level: sum(1 for x in lows if abs(x - level) <= sensitivity * level) for level in support_levels}

    filtered_resistances = [level for level, count in resistance_counts.items() if count >= min_touch]
    filtered_supports = [level for level, count in support_counts.items() if count >= min_touch]

    # 🔹 COMPLEMENTAR CON SOPORTES Y RESISTENCIAS DE LA VENTANA MÓVIL
    window = 20  # Últimos 20 días
    rolling_support = df["low"].rolling(window=window).min().iloc[-1]
    rolling_resistance = df["high"].rolling(window=window).max().iloc[-1]

    # 🔹 COMBINAR RESULTADOS
    support = min(filtered_supports) if filtered_supports else rolling_support
    resistance = max(filtered_resistances) if filtered_resistances else rolling_resistance

    return round(support, 2), round(resistance, 2)