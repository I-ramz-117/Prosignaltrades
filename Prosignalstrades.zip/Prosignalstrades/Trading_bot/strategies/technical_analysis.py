import time
import numpy as np
from Trading_bot.indicators.current_price import get_current_price
from Trading_bot.indicators.indicators import get_stock_data, calculate_technical_indicators
from Trading_bot.strategies.support_resistance import calculate_support_resistance
from Trading_bot.strategies.candlestick_patterns import detect_candlestick_patterns


def safe_float(value):
    """Convierte un valor a float si es posible, de lo contrario devuelve NaN."""
    try:
        if value is None or value == "N/A":
            return np.nan  # Evita errores si el valor es None o una cadena no numérica
        return float(value)
    except ValueError:
        return np.nan


def format_value(value):
    """Formatea valores numéricos con 2 decimales, o devuelve el texto si es 'N/A'."""
    return f"{value:.2f}" if isinstance(
        value, (int, float)) and not np.isnan(value) else value


def technical_analysis(symbol):
    df = get_stock_data(
        symbol)  # 📌 Ahora se obtiene la acción antes de calcular indicadores
    if df is None:
        return "❌ No se encontraron datos para esta acción."

    try:
        start_time = time.time()

        # 📌 Obtener el precio en tiempo real
        current_price, timestamp = get_current_price(symbol)
        current_price = safe_float(current_price)  # Asegurar que es float

        # 📊 Cálculo de indicadores técnicos
        df = calculate_technical_indicators(df)

        # 📌 Calcular soportes y resistencias
        support, resistance = calculate_support_resistance(df)
        support = safe_float(support)
        resistance = safe_float(resistance)
        # 📌 Detectar patrones de velas japonesas mejorados
        candle_patterns = detect_candlestick_patterns(df)

        # 📌 Extraer valores para análisis
        rsi_value = safe_float(df["RSI"].iloc[-1])
        macd_value = safe_float(df["MACD"].iloc[-1])
        macd_signal_value = safe_float(df["MACD_Signal"].iloc[-1])
        adx_value = safe_float(df["ADX"].iloc[-1])
        bb_high = safe_float(df["BB_High"].iloc[-1])
        bb_low = safe_float(df["BB_Low"].iloc[-1])
        ema_20 = safe_float(df["EMA_20"].iloc[-1])
        ema_50 = safe_float(df["EMA_50"].iloc[-1])
        latest_volume = safe_float(df["volume"].iloc[-1])
        avg_volume = safe_float(df["SMA_14"].iloc[-1])

        # Extraer precios y RSI de las últimas dos velas
        previous_price = safe_float(df["close"].iloc[-2])
        current_price = safe_float(df["close"].iloc[-1])
        previous_rsi = safe_float(df["RSI"].iloc[-2])
        current_rsi = safe_float(df["RSI"].iloc[-1])

        rsi_divergence = "⚪ Sin divergencias en RSI."

        # 📉 Divergencia Alcista (precio más bajo, RSI más alto)
        if current_price < previous_price and current_rsi > previous_rsi:
            rsi_divergence = "🟢 Divergencia Alcista en RSI - Posible reversión alcista."

        # 📈 Divergencia Bajista (precio más alto, RSI más bajo)
        elif current_price > previous_price and current_rsi < previous_rsi:
            rsi_divergence = "🔴 Divergencia Bajista en RSI - Posible reversión bajista."

        # Extraer valores de MACD de las últimas dos velas
        previous_macd = safe_float(df["MACD"].iloc[-2])
        current_macd = safe_float(df["MACD"].iloc[-1])

        macd_divergence = "⚪ Sin divergencias en MACD."

        # 📉 Divergencia Alcista (precio más bajo, MACD más alto)
        if current_price < previous_price and current_macd > previous_macd:
            macd_divergence = "🟢 Divergencia Alcista en MACD - Posible reversión alcista."

        # 📈 Divergencia Bajista (precio más alto, MACD más bajo)
        elif current_price > previous_price and current_macd < previous_macd:
            macd_divergence = "🔴 Divergencia Bajista en MACD - Posible reversión bajista."

        buy_signals = 0
        sell_signals = 0

        # 📈 Criterios de Compra Mejorados
        if rsi_value < 30 and df["RSI"].iloc[-2] < 30 and rsi_value > df[
                "RSI"].iloc[-2]:
            buy_signals += 2  # RSI subiendo desde sobreventa

        if macd_value > macd_signal_value and macd_value > 0:
            buy_signals += 2  # MACD cruzó alcista y está en zona positiva

        if ema_20 > ema_50 and df["EMA_20"].iloc[-2] > df["EMA_50"].iloc[-2]:
            buy_signals += 1  # EMA 20 confirma cruce sobre EMA 50

        if latest_volume > avg_volume * 1.2 and buy_signals > 0:
            buy_signals += 1  # Volumen alto refuerza señal de compra

        if current_price <= bb_low and rsi_value < 40 and macd_value > 0:
            buy_signals += 1  # Precio en banda inferior + RSI bajo + MACD positivo

        # 📉 Criterios de Venta Mejorados
        if rsi_value > 70 and df["RSI"].iloc[-2] > 70 and rsi_value < df[
                "RSI"].iloc[-2]:
            sell_signals += 2  # RSI bajando desde sobrecompra

        if macd_value < macd_signal_value and macd_value < 0:
            sell_signals += 2  # MACD cruzó bajista y está en zona negativa

        if ema_20 < ema_50 and df["EMA_20"].iloc[-2] < df["EMA_50"].iloc[-2]:
            sell_signals += 1  # EMA 20 confirma cruce bajo EMA 50

        if latest_volume < avg_volume * 0.8 and sell_signals > 0:
            sell_signals += 1  # Volumen bajo refuerza señal de venta

        if current_price >= bb_high and rsi_value > 60 and macd_value < 0:
            sell_signals += 1  # Precio en banda superior + RSI alto + MACD negativo

        # 📌 Si hay valores NaN, devolver error
        if np.isnan(current_price) or np.isnan(bb_high) or np.isnan(bb_low):
            return {
                "text":
                f"❌ Error: Datos insuficientes para el análisis técnico de {symbol}."
            }

        # 📌 Interpretación del Volumen
        percentile_75 = np.percentile(df["volume"], 75)
        percentile_25 = np.percentile(df["volume"], 25)

        if latest_volume > percentile_75:
            volume_signal = "🟢 Volumen Alto - Confirma tendencia."
        elif latest_volume < percentile_25:
            volume_signal = "🔴 Volumen Bajo - Puede indicar falta de interés."
        else:
            volume_signal = "⚪ Volumen Normal."

        if rsi_value > 80:
            rsi_explanation = "⚠️ RSI extremadamente sobrecomprado, alta probabilidad de corrección."
        elif rsi_value > 70:
            rsi_explanation = "🔴 RSI en sobrecompra, posible reversión bajista."
        elif rsi_value < 20:
            rsi_explanation = "⚠️ RSI extremadamente sobrevendido, posible rebote fuerte."
        elif rsi_value < 30:
            rsi_explanation = "🟢 RSI en sobreventa, posible rebote alcista."
        elif 40 <= rsi_value < 50:
            rsi_explanation = "🟡 RSI en acumulación antes de una subida."
        elif 50 <= rsi_value < 60:
            rsi_explanation = "🟡 RSI en leve sobrecompra, pero no alarmante."
        else:
            rsi_explanation = "⚪ RSI en zona neutral."

        # 🔹 Interpretación avanzada del MACD
        previous_macd = safe_float(
            df["MACD"].iloc[-2])  # Valor del MACD en la vela anterior

        if macd_value > macd_signal_value and macd_value > 0:
            macd_explanation = "🟢 MACD fuerte alcista, tendencia confirmada."
        elif macd_value > macd_signal_value and macd_value < 0:
            macd_explanation = "🟡 MACD cruzó alcista pero sigue en zona negativa."
        elif macd_value < macd_signal_value and macd_value < 0:
            macd_explanation = "🔴 MACD bajista y en zona negativa."
        elif macd_value < macd_signal_value and macd_value > 0:
            macd_explanation = "🟡 MACD bajista pero sigue en zona positiva."
        elif macd_value < previous_macd and macd_value > 0:
            macd_explanation = "⚠️ MACD perdiendo momentum, posible corrección."
        elif macd_value > previous_macd and macd_value < 0:
            macd_explanation = "🟢 MACD subiendo en zona negativa, posible reversión alcista."
        else:
            macd_explanation = "⚪ MACD sin señal clara."

        # 🔹 Interpretación del ADX
        if adx_value < 15:
            adx_explanation = "⚠️ ADX muy bajo, mercado lateral."
        elif adx_value < 25:
            adx_explanation = "⚠️ ADX bajo, tendencia débil o mercado lateral."
        elif adx_value < 40:
            adx_explanation = "💪 ADX indica una tendencia fuerte."
        else:
            adx_explanation = "🔥 ADX extremadamente fuerte, alta volatilidad."

        # 🔹 Interpretación de Bandas de Bollinger
        bollinger_width = bb_high - bb_low
        percentile_25_bw = np.percentile(df["BB_High"] - df["BB_Low"], 25)

        if current_price >= bb_high:
            bb_explanation = "🔴 Precio en la banda superior de Bollinger, posible sobrecompra."
        elif current_price <= bb_low:
            bb_explanation = "🟢 Precio en la banda inferior de Bollinger, posible sobreventa."
        elif bollinger_width < percentile_25_bw:
            bb_explanation = "⚠️ Bandas de Bollinger comprimidas, posible explosión de volatilidad."
        else:
            bb_explanation = "⚪ Precio dentro de las bandas de Bollinger, sin señal clara."

        # 🔹 Interpretación del cruce de EMAs

        if ema_20 > ema_50:
            ema_explanation = "🟢 EMA 20 sobre EMA 50, tendencia alcista."
        else:
            ema_explanation = "🔴 EMA 20 debajo de EMA 50, tendencia bajista."

        # 📌 Estrategias adicionales con peso mejorado
        buy_signals = 0
        sell_signals = 0

        if rsi_value < 30 and macd_value > macd_signal_value:
            buy_signals += 2
        elif rsi_value < 30 or macd_value > macd_signal_value:
            buy_signals += 1

        if rsi_value > 70 and macd_value < macd_signal_value:
            sell_signals += 2
        elif rsi_value > 70 or macd_value < macd_signal_value:
            sell_signals += 1

        if ema_20 > ema_50:
            buy_signals += 1
        else:
            sell_signals += 1

        if latest_volume > avg_volume * 1.2:
            buy_signals += 1
        elif latest_volume < avg_volume * 0.8:
            sell_signals += 1

        # 📌 Calcular la confianza en la recomendación
        total_signals = buy_signals + sell_signals
        confidence = round((max(buy_signals, sell_signals) / 5) *
                           100, 1) if total_signals > 0 else 0

        # 📌 Nueva interpretación de señales con confianza
        if buy_signals >= 4:
            trade_signal = "📈 COMPRA FUERTE"
        elif buy_signals == 3:
            trade_signal = "📊 COMPRA MODERADA"
        elif sell_signals >= 4:
            trade_signal = "📉 VENTA FUERTE"
        elif sell_signals == 3:
            trade_signal = "📊 VENTA MODERADA"
        else:
            trade_signal = "🔍 MANTENER - No hay señales claras."

        # 📌 Agregar confianza al mensaje
        trade_signal += f" ({confidence}% de confianza)"

        # 📌 Estrategia de Entrada y Stop-Loss con ATR (corregido)
        last_price = safe_float(df["close"].iloc[-1])
        atr_value = safe_float(df["ATR"].iloc[-1]) * 0.5

        # 📌 Definir valores predeterminados antes del cálculo
        entry_price, stop_loss, target_1, target_2, break_even = "N/A", "N/A", "N/A", "N/A", "N/A"

        # 📌 Verificación de ATR antes de seguir
        if not np.isnan(atr_value):
            if "COMPRA" in trade_signal:
                entry_price = last_price * 1.002
                stop_loss = entry_price - atr_value
                target_1 = entry_price + (atr_value * 1.5)
                target_2 = entry_price + (atr_value * 2.5)
                break_even = entry_price + (atr_value * 0.5)
            elif "VENTA" in trade_signal:
                entry_price = last_price * 0.998
                stop_loss = entry_price + atr_value
                target_1 = entry_price - (atr_value * 1.5)
                target_2 = entry_price - (atr_value * 2.5)
                break_even = entry_price - (atr_value * 0.5)

        execution_time = time.time() - start_time
        print(f"✅ Análisis técnico generado en {execution_time:.2f} segundos.")

        return {
            "text":
            f"""📊 *Análisis Técnico de {symbol}*

📌 *Precio Actual:* **{format_value(current_price)} USD** *(Última actualización: {timestamp})* 💰

🔹 *RSI:* {format_value(rsi_value)}
   {rsi_explanation}
   {rsi_divergence}

🔹 *MACD:* {format_value(macd_value)} (Señal: {format_value(macd_signal_value)})
   {macd_explanation}
   {macd_divergence}

🔹 *ADX:* {format_value(adx_value)}
   {("💪 ADX indica una tendencia fuerte." if adx_value > 25 else "⚠️ ADX bajo, tendencia débil o mercado lateral.") if isinstance(adx_value, (int, float)) else "⚪ ADX no disponible."}

🔹 *Bandas de Bollinger:*
   - Banda Superior: {format_value(bb_high)}
   - Banda Inferior: {format_value(bb_low)}
   {("🔴 Precio en la banda superior de Bollinger, posible sobrecompra." if current_price >= bb_high else
    "🟢 Precio en la banda inferior de Bollinger, posible sobreventa." if current_price <= bb_low else
    "⚪ Precio dentro de las bandas de Bollinger, sin señal clara.") if isinstance(current_price, (int, float)) and isinstance(bb_high, (int, float)) and isinstance(bb_low, (int, float)) else "⚪ Bandas de Bollinger no disponibles."}

🔹 *EMA:* {format_value(ema_20)} / {format_value(ema_50)}
   {ema_explanation}

🔹 *Volumen:* {format_value(latest_volume)} (Media: {format_value(avg_volume)})
   {volume_signal}

🔹 *Soporte:* {format_value(support)}
🔹 *Resistencia:* {format_value(resistance)}

🔹 *Patrones de Velas:*
   {candle_patterns}

📌 *{trade_signal}*

🎯 *Estrategia de Entrada:*
   - Entrada: {format_value(entry_price)}
   - Stop-Loss (SL): {format_value(stop_loss)}
   - Break-Even (BE): {format_value(break_even)}
   - Take-Profit 1 (TP1): {format_value(target_1)}
   - Take-Profit 2 (TP2): {format_value(target_2)}
"""
        }

    except Exception as e:
        print(f"❌ Error en el análisis técnico de {symbol}: {e}")
        return "❌ Hubo un error procesando el análisis técnico."
